# Artist Portfolio — GitHub Pages Template

A responsive, one-page artist portfolio made with plain HTML, CSS, and JavaScript. No build tools, package installs, or paid hosting required. It is ready to publish with GitHub Pages.

## Preview locally

Open `index.html` in a browser. For the most reliable local preview, use VS Code's Live Server extension or run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Personalize it

1. **Name and title:** In `index.html`, replace “Alex Taylor,” “AT,” the page title, location, biography, and email address.
2. **Projects:** Open `script.js` and edit the `projects` array near the top. Each project has a title, category (`painting`, `digital`, or `objects`), year, image URL, alt text, and description. Add or remove entries as needed.
3. **Images:** Replace the sample Unsplash image URLs with your own image URLs or paths, such as `images/my-painting.jpg`. Create an `images` folder in the repo for local images.
4. **Colors and typography:** Edit the CSS variables at the top of `styles.css`.
5. **Links:** Replace the sample Instagram, Behance, and email links in `index.html`.

## Publish on GitHub Pages

1. Sign in to GitHub and create a new repository. For a personal site, name it `YOUR-USERNAME.github.io`. For a project site, any repository name is fine.
2. Upload **the contents of this folder** (`index.html`, `styles.css`, `script.js`, `README.md`) to the repository's root. Do not upload the enclosing folder as an extra nested directory.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**. Select branch `main` and folder `/ (root)`, then save.
5. Wait for the Pages deployment to finish. GitHub will show the published URL in the Pages settings.

For a personal repository, the URL is usually `https://YOUR-USERNAME.github.io/`. For a project repository, it is usually `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Notes

- This is a static site, so it works with GitHub Pages as-is.
- Sample artwork images are loaded from Unsplash. Replace them with your own images before publishing if you prefer.
- The contact link uses `mailto:`; it opens the visitor's email app rather than submitting a server-side form.
